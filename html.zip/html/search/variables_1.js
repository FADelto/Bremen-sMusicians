var searchData=
[
  ['user_0',['USER',['../enumcom_1_1example_1_1_quiet_melody_1_1domain_1_1_role.html#a40ac08c7c2464812a509b1a17bc8c47a',1,'com::example::QuietMelody::domain::Role']]]
];
