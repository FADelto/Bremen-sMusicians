var searchData=
[
  ['admin_0',['ADMIN',['../enumcom_1_1example_1_1_quiet_melody_1_1domain_1_1_role.html#a73464ed5d2a0e3f18275a27c69aa2f78',1,'com::example::QuietMelody::domain::Role']]]
];
